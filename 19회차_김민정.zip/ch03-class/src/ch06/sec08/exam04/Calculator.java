package ch06.sec08.exam04;

public class Calculator {
    double areaRectangle(double side) {
        return side * side;
    }

    double areaRectangle(double length, double width) {
        return length * width;
    }
}
